﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snake
{
    class Apple : FruitBase
    {
        public override void ChangeSnakeLength(List<Vector2> bodyPos, Vector2 headPos, ref int scoreInt)
        {
            if (bodyPos.Count == 0)
            {
                bodyPos.Add(headPos);
            }
            else
            {
                for (int x = 0; x < 8; x++)
                {
                    bodyPos.Add(headPos);
                }
            }
        }
        public override void Draw()
        {
            base.Draw();
        }
    }
}