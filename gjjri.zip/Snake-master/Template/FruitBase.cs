﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snake
{
    abstract class FruitBase
    {
        public int ScoreInt { get; protected set; }
        public Texture2D FruitTex { get; protected set; }
        public Vector2 FruitPos { get; protected set; }

        public abstract void ChangeSnakeLength(List<Vector2> bodyPos, Vector2 headPos, ref int scoreInt);
        public virtual void Draw() { }
    }
}
